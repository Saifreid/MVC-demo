package edu.psu.ist.controller;

import edu.psu.ist.model.*;
import edu.psu.ist.view.ListView;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ListController implements ActionListener {

    private ListView listView;

    List<Game> games = new ArrayList<>();

    GameTableModel gameTableModel;

    GameController gameController;

    public ListController() {
        createInitialElements();
        this.gameTableModel = new GameTableModel(games);
        this.listView = new ListView(this);
        addActionListeners();
    }

    public GameTableModel getGameTableModel() {
        return this.gameTableModel;
    }

    public List<Game> getGames() {
        return games;
    }

    private void createInitialElements() {
        //Genre Creation
        ArrayList<String> genres1 = new ArrayList<String>(Arrays.asList("Survival", "Sandbox"));
        ArrayList<String> genres2 = new ArrayList<String>(Arrays.asList("RPG", "Fantasy"));
        ArrayList<String> genres3 = new ArrayList<String>(Arrays.asList("Survival", "Sandbox", "Farming"));

        //Rating Creation
        ArrayList<Double> rating1 = new ArrayList<>(Arrays.asList(97.0, 99.0));
        ArrayList<Double> rating2 = new ArrayList<>(Arrays.asList(90.0, 92.0));
        ArrayList<Double> rating3 = new ArrayList<>(Arrays.asList(95.0, 96.0));

        //Founder Creation
        Founder founder1 = new Founder("Markus Persson", 44);
        Founder founder2 = new Founder("Todd Howard", 57);
        Founder founder3 = new Founder("Eric Barone", 36);

        //GameCompany Creation
        GameCompany gameCompany1 = new GameCompany("Mojang", "SM", "Sweden", 2009, genres1);
        GameCompany gameCompany2 = new GameCompany("Bethesda", "MD", "US", 1998, genres2);
        GameCompany gameCompany3 = new GameCompany("ConcernedApe", "SM", "US", 2005, genres3);

        //Game Creation
        Game game1 = new Game("Minecraft", gameCompany1, "E", genres1, rating1, "Block based survival game", true);
        Game game2 = new Game("Skyrim", gameCompany2, "M", genres2, rating2, "Fantasy role playing game", false);
        Game game3 = new Game("Stardew Valley", gameCompany3, "E", genres3, rating3, "Fun farming simlulator with some fantasy elements", true);

        //Adding games to the games list
        games.add(game1);
        games.add(game2);
        games.add(game3);

    }


    public void addActionListeners() {
        listView.getNewButton().addActionListener(this);
        listView.getShowDetailsButton().addActionListener(this);
        listView.getDoneButton().addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == listView.getNewButton()) {
            //instantiate InstrumentController without the selectedRow

            this.gameController = new GameController(this);
            listView.dispose();

            //it may require new constructor in InstrumentController that accepts ListController as a parameter
            //make sure to clear the fields on the details view
        }

        if (e.getSource() == listView.getShowDetailsButton()) {
            int selectedRow = listView.getTblGame().getSelectedRow();
            if (selectedRow != -1) {
                listView.dispose();

                System.out.println("Selected Row = " + selectedRow);

                //if no row is selected on the list, set it to show first element on the details view
                //show a detail view with the data for the selected element
                //pass the flow from list controller to details controller
                //do not instantiate the details view from this list controller

                this.gameController = new GameController(this, selectedRow);

            } else {
                listView.dispose();
                this.gameController = new GameController(this, 0);
            }
        }

            if (e.getSource() == listView.getDoneButton()) {
                //implement functionality
                listView.dispose();
            }


        }


        public void showListView() {
            this.listView.setVisible(true);
        }

}

