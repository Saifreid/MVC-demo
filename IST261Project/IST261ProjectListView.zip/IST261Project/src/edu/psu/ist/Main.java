package edu.psu.ist;

import edu.psu.ist.controller.GameController;
import edu.psu.ist.controller.ListController;

public class Main {
    public static void main(String[] args) {
        //GameController gameController = new GameController();
        new ListController();
    }
}
