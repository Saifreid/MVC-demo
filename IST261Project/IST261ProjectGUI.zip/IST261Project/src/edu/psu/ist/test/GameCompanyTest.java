package edu.psu.ist.test;

public class GameCompanyTest {
}
