package edu.psu.ist.model;

public interface PlayerGame {
    public String isThisMultiplayer();
    public String playerCountString();

}
