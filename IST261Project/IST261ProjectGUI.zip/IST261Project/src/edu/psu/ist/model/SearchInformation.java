package edu.psu.ist.model;

public interface SearchInformation {
    public String getInformationType();
    public boolean getIsSearchable();
}
