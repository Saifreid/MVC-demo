package edu.psu.ist;

import edu.psu.ist.controller.GameController;
public class Main {
    public static void main(String[] args) {
        GameController gameController = new GameController();

    }
}
