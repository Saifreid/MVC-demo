package edu.psu.ist.controller;

import edu.psu.ist.model.*;
import edu.psu.ist.view.GameInfoView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class GameController implements ActionListener {

    private GameInfoView gameInfoView;

    private List<Game> games = new ArrayList<>();

    int currentIndex;

    public GameController(){
        this.gameInfoView = new GameInfoView(this);
        addActionListeners();
        createInitialGames();

    }
    public void displayGame(int index){
        Game currentGame = games.get(index);
        gameInfoView.displayGame(currentGame);
    }

    private void createInitialGames() {
        //Genre Creation
        ArrayList<String> genres1 = new ArrayList<String>(Arrays.asList("Survival", "Sandbox"));
        ArrayList<String> genres2 = new ArrayList<String>(Arrays.asList("RPG", "Fantasy"));
        ArrayList<String> genres3 = new ArrayList<String>(Arrays.asList("Survival", "Sandbox", "Farming"));

        //Rating Creation
        ArrayList<Double> rating1 = new ArrayList<>(Arrays.asList(97.0, 99.0));
        ArrayList<Double> rating2 = new ArrayList<>(Arrays.asList(90.0, 92.0));
        ArrayList<Double> rating3 = new ArrayList<>(Arrays.asList(95.0, 96.0));

        //Founder Creation
        Founder founder1 = new Founder("Markus Persson", 44);
        Founder founder2 = new Founder("Todd Howard", 57);
        Founder founder3 = new Founder("Eric Barone", 36);

        //GameCompany Creation
        GameCompany gameCompany1 = new GameCompany("Mojang", "SM", "Sweden", 2009, genres1);
        GameCompany gameCompany2 = new GameCompany("Bethesda", "MD", "US", 1998, genres2);
        GameCompany gameCompany3 = new GameCompany("ConcernedApe", "SM", "US", 2005, genres3);

        //Game Creation
        Game game1 = new Game("Minecraft", gameCompany1, "E", genres1,rating1, "Block based survival game",true);
        Game game2 = new Game("Skyrim",gameCompany2, "M", genres2, rating2, "Fantasy role playing game", false);
        Game game3 = new Game("Stardew Valley", gameCompany3, "E", genres3, rating3, "Fun farming simlulator with some fantasy elements", true);

        //Adding games to the games list
        games.add(game1);
        games.add(game2);
        games.add(game3);

        //Setting up GUI
        currentIndex = 0;
        displayGame(0);

    }

    private void addActionListeners() {
        gameInfoView.getCreateButton().addActionListener(this);
        gameInfoView.getDeleteButton().addActionListener(this);
        gameInfoView.getNextButton().addActionListener(this);
        gameInfoView.getPrevButton().addActionListener(this);
        gameInfoView.getSaveButton().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        JButton actionSource = (JButton)e.getSource();
        //This is for Create Button
        if(actionSource == gameInfoView.getCreateButton()){
            try {
                games.add(gameInfoView.createGame());
                gameInfoView.clearFields();
                currentIndex = 0;
                displayGame(currentIndex);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(gameInfoView, "Failed to create");

                throw new RuntimeException(ex);
            }
        }
        //This is for Delete Button
        if(actionSource == gameInfoView.getDeleteButton()){
            games.remove(currentIndex);
            currentIndex = 0;
            gameInfoView.clearFields();
            displayGame(currentIndex);
        }
        //This is for Next Button
        if(actionSource == gameInfoView.getNextButton()){
            currentIndex += 1;
            if(currentIndex == games.size()){
                currentIndex = 0;
            }
            gameInfoView.clearFields();
            displayGame(currentIndex);
        }
        //This is for Prev Button
        if(actionSource == gameInfoView.getPrevButton()){
            currentIndex -= 1;
            if(currentIndex < 0){
                currentIndex = games.size() -1;
            }

            gameInfoView.clearFields();
            displayGame(currentIndex);
        }
        //This is for Save Button
        if(actionSource == gameInfoView.getSaveButton()){
            try {
                gameInfoView.updateGame(games,currentIndex);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(gameInfoView, "Error cannot save");

                throw new RuntimeException(ex);
            }
        }

    }
}
